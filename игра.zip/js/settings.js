const settings_tps = 20
const settings_timeToDie = 13
const settings_playerRadius = 10
const settings_switchRadius = 15
const settings_playerSpeed = 5
const settings_maxGhosts = 4

const glScale = 1 / 100
const glSwitchRadius = 20
